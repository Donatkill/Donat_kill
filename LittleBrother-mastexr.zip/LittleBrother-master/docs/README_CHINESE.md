#LittleBrother#
##小弟弟插件##

>一个能让 MinecraftPocketEdition 玩家进入 CraftBukkit 水桶服务器，并与 Minecraft 玩家共同游戏的插件

###用法及疑难解答：###
请查看LittleBrother Wiki.

###插件指令###
`/LittleBrother`

`/lb`
