LittleBrother Плагин

>Позволяет играть с Minecraft: Pocket Edition на CraftBukkit сервере!

###Есть проблемы?
Пожалуйста, проверьте  LittleBrother  Wiki. 

###Доступные команды

`/LittleBrother`

`/lb`
