LittleBrother
===
>A CraftBukkit plugin that allows players who are playing Minecraft : Pocket Edition join in the CraftBukkit server.

###Commands###
`/LittleBrother`
`/lb`
