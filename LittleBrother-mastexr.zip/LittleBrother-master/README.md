#LittleBrother#

A CraftBukkit plugin that allows players who are playing Minecraft : Pocket Edition join in the CraftBukkit server.

###Documents###
Find more information in those links

[English](https://github.com/ljyloo/LittleBrother/blob/master/docs/README_ENGLISH.md)

[中文(简体)](https://github.com/ljyloo/LittleBrother/blob/master/docs/README_CHINESE.md)

[Русский](https://github.com/ljyloo/LittleBrother/blob/master/docs/README_RUSSIAN.md)

[Spanish](https://github.com/ljyloo/LittleBrother/blob/master/docs/README_SPANISH.md)
