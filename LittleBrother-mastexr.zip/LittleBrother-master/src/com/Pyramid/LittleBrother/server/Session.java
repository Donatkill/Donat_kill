package com.Pyramid.LittleBrother.server;

/**
 * TODO
 * 
 * @see SessionManager
 */
class Session{
	
}