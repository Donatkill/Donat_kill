package com.Pyramid.LittleBrother.network.protocol;

class SetTimePacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.SET_TIME_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}
