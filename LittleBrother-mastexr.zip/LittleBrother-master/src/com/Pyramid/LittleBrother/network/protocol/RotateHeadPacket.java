package com.Pyramid.LittleBrother.network.protocol;

class RotateHeadPacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.ROTATE_HEAD_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}
