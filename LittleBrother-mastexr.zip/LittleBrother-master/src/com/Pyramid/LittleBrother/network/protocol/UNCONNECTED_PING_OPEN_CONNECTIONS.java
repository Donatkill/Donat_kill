package com.Pyramid.LittleBrother.network.protocol;

class UNCONNECTED_PING_OPEN_CONNECTIONS extends UNCONNECTED_PING{
	public byte ID = 0x02;
}
