package com.Pyramid.LittleBrother.network.protocol;

class EntityDataPacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.ENTITY_DATA_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}