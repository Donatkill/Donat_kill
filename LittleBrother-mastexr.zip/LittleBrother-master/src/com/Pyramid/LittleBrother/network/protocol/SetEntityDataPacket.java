package com.Pyramid.LittleBrother.network.protocol;

class SetEntityDataPacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.SET_ENTITY_DATA_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}