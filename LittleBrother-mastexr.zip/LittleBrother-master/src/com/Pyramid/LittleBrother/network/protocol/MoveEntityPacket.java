package com.Pyramid.LittleBrother.network.protocol;

class MoveEntityPacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.MOVE_ENTITY_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}