package com.Pyramid.LittleBrother.network.protocol;

class SetEntityMotionPacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.SET_ENTITY_MOTION_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}