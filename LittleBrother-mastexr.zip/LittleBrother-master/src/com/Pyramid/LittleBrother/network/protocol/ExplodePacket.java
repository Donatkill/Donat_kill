package com.Pyramid.LittleBrother.network.protocol;

class ExplodePacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.EXPLODE_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}