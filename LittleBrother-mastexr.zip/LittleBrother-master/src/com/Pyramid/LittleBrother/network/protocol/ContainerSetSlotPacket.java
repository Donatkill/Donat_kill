package com.Pyramid.LittleBrother.network.protocol;

class ContainerSetSlotPacket extends DataPacket{

	@Override
	public byte pid() {
		return Info.CONTAINER_SET_SLOT_PACKET;
	}

	@Override
	public void encode() {
		
	}

	@Override
	public void decode() {
		
	}
	
}